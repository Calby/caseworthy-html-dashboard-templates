---
name: caseworthy-html-builder
description: "Build HTML/CSS templates for CaseWorthy's WYSIWYG editor. Use when creating workspace dashboards, help center pages, case note templates, email templates, or any custom HTML layout inside CaseWorthy. Handles all platform constraints automatically: inline CSS only, no JavaScript, SVG icons, system fonts. Triggers on: 'build a dashboard', 'help center page', 'case note template', 'CaseWorthy HTML', 'workspace page', 'WYSIWYG template', 'email template for CaseWorthy', or any request to create HTML that will be pasted into CaseWorthy's editor."
---

# CaseWorthy HTML/CSS Builder

Build HTML templates that work inside CaseWorthy's WYSIWYG editor. One request produces copy-paste ready HTML.

## Platform Constraints

These rules apply to EVERY build. Do not deviate.

### 1. Inline CSS Only
- Every element gets styles via `style=""` attribute
- Do NOT use `<style>` blocks
- Do NOT use `<link>` to external stylesheets
- Do NOT use CSS classes or IDs for styling

```html
<!-- CORRECT -->
<div style="background-color: #1a5276; padding: 20px; border-radius: 8px;">

<!-- WRONG -->
<style>.hero { background-color: #1a5276; }</style>
<div class="hero">
```

### 2. No JavaScript
- CaseWorthy strips all JavaScript
- No `<script>` tags
- No `onclick`, `onload`, or any event handlers
- No dynamic behavior of any kind
- Interactive elements are limited to `<a href="">` links

### 3. Icons
- Use inline SVG with `viewBox` for icons (confirmed working in CaseWorthy)
- Use Unicode emoji as an alternative: `&#128200;` or paste directly
- Do NOT use icon libraries (Font Awesome, Material Icons, Lucide)
- Do NOT reference external image URLs unless user provides them

```html
<!-- SVG Icon Example -->
<svg viewBox="0 0 48 48" width="32" height="32">
  <circle cx="24" cy="24" r="20" fill="none" stroke="#ffffff" stroke-width="3"/>
</svg>

<!-- Emoji Example -->
<span style="font-size: 18px;">&#128203;</span>
```

### 4. Fonts
- System fonts only: `font-family: Arial, sans-serif;`
- Do NOT load Google Fonts or any external fonts
- Always specify `font-family` in inline styles

### 5. Layout
- Flexbox works: `style="display: flex; gap: 20px;"`
- Inline-block works: `style="display: inline-block; width: 30%;"`
- Use `min-width` on flex children for responsive behavior
- Use `flex-wrap: wrap;` for mobile fallback
- Tables are fine for actual tabular data

### 6. Links
- Standard `<a href="URL">` tags
- Use placeholder URLs: `#HELPDESK_URL`, `#ARTICLE_URL`, `#ENROLLMENT_URL`
- Include comment noting all placeholder URLs for find-and-replace

### 7. Colors
- Hex codes in inline styles
- Maintain consistent palette across the template
- Ensure accessible contrast ratios

### 8. Output Format
- Raw HTML only — no markdown fences wrapping the output
- HTML comments at the top identifying the template
- HTML comments before each major section
- Copy-paste ready for CaseWorthy's WYSIWYG editor

## Template Types

When user requests a template, identify which type and follow the corresponding pattern:

### Help Center Dashboard
Sections: Hero banner with stats → Quick action cards (3 across) → Two-column workflow navigation → Manager resources → Footer

### Case Note Template
Sections: Client/program header bar → Contact info fields → Note category area → Case note body → Follow-up actions → Supervisor review area

### Program Dashboard
Sections: Program header → Key metrics row → Workflow navigation list → Quick links → Recent announcements → Program contacts

### Workspace Landing Page
Sections: Welcome banner → Navigation cards → Resource links → Announcements → Contact info

### Email Template
Sections: Header with logo placeholder → Content area → Action button (styled link) → Footer with contact info. Max width 600px.

### Announcement Banner
Single element: Colored bar with icon, title, message, optional link. Provide versions for info (blue), warning (yellow), critical (red), success (green).

### Training Resource Page
Sections: Video tutorials list → Written guides list → Quick reference cards → FAQ → Training contact info

### Staff Directory
Sections: Card grid layout → Each card: name, title, department, phone, email. 2-3 cards per row.

## Build Workflow

1. **Confirm type** — Ask user which template type they need if not clear
2. **Gather specifics** — What sections, how many items, what colors, what content
3. **Build HTML** — Follow all constraints above
4. **Add placeholders** — Use `#URL_NAME` format for all links
5. **Add comments** — Section markers and customization notes
6. **Output** — Deliver raw HTML, no code fences, no extra explanation mixed in

## SVG Icon Library

Use these pre-built icons in templates. Change `stroke` or `fill` colors as needed.

### Document
```html
<svg viewBox="0 0 48 48" width="32" height="32"><path d="M14 6 L14 42 L34 42 L34 14 L26 6 Z" fill="none" stroke="#ffffff" stroke-width="3" stroke-linejoin="round"/><path d="M26 6 L26 14 L34 14" fill="none" stroke="#ffffff" stroke-width="3" stroke-linejoin="round"/></svg>
```

### Checkmark
```html
<svg viewBox="0 0 48 48" width="32" height="32"><circle cx="24" cy="24" r="20" fill="none" stroke="#27ae60" stroke-width="3"/><path d="M14 24 L21 31 L34 18" fill="none" stroke="#27ae60" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>
```

### Person
```html
<svg viewBox="0 0 48 48" width="32" height="32"><circle cx="24" cy="16" r="8" fill="none" stroke="#ffffff" stroke-width="3"/><path d="M8 42 C8 32 16 26 24 26 C32 26 40 32 40 42" fill="none" stroke="#ffffff" stroke-width="3"/></svg>
```

### Gear
```html
<svg viewBox="0 0 48 48" width="32" height="32"><circle cx="24" cy="24" r="8" fill="none" stroke="#ffffff" stroke-width="3"/><circle cx="24" cy="24" r="16" fill="none" stroke="#ffffff" stroke-width="3" stroke-dasharray="6 4"/></svg>
```

### Search
```html
<svg viewBox="0 0 48 48" width="32" height="32"><circle cx="20" cy="20" r="12" fill="none" stroke="#ffffff" stroke-width="3"/><line x1="29" y1="29" x2="40" y2="40" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/></svg>
```

### Warning
```html
<svg viewBox="0 0 48 48" width="32" height="32"><path d="M24 6 L42 40 L6 40 Z" fill="none" stroke="#f39c12" stroke-width="3" stroke-linejoin="round"/><line x1="24" y1="18" x2="24" y2="30" stroke="#f39c12" stroke-width="3" stroke-linecap="round"/><circle cx="24" cy="35" r="1.5" fill="#f39c12"/></svg>
```

### Calendar
```html
<svg viewBox="0 0 48 48" width="32" height="32"><rect x="6" y="10" width="36" height="32" rx="4" fill="none" stroke="#ffffff" stroke-width="3"/><line x1="6" y1="20" x2="42" y2="20" stroke="#ffffff" stroke-width="3"/><line x1="16" y1="6" x2="16" y2="14" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/><line x1="32" y1="6" x2="32" y2="14" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/></svg>
```

### Money
```html
<svg viewBox="0 0 48 48" width="32" height="32"><circle cx="24" cy="24" r="20" fill="none" stroke="#ffffff" stroke-width="3"/><text x="24" y="30" text-anchor="middle" fill="#ffffff" font-size="20" font-family="Arial" font-weight="bold">$</text></svg>
```

### Chart
```html
<svg viewBox="0 0 48 48" width="32" height="32"><rect x="6" y="28" width="8" height="14" rx="1" fill="#ffffff"/><rect x="20" y="18" width="8" height="24" rx="1" fill="#ffffff"/><rect x="34" y="8" width="8" height="34" rx="1" fill="#ffffff"/></svg>
```

### Megaphone
```html
<svg viewBox="0 0 48 48" width="32" height="32"><path d="M8 20 L8 28 L16 28 L28 38 L28 10 L16 20 Z" fill="none" stroke="#ffffff" stroke-width="3" stroke-linejoin="round"/><path d="M34 18 C37 21 37 27 34 30" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round"/><path d="M38 14 C43 19 43 29 38 34" fill="none" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round"/></svg>
```

### Ticket / Support
```html
<svg viewBox="0 0 48 48" width="32" height="32"><rect x="4" y="8" width="40" height="28" rx="4" fill="none" stroke="#ffffff" stroke-width="3"/><line x1="12" y1="18" x2="36" y2="18" stroke="#ffffff" stroke-width="2"/><line x1="12" y1="24" x2="30" y2="24" stroke="#ffffff" stroke-width="2"/><line x1="12" y1="30" x2="24" y2="30" stroke="#ffffff" stroke-width="2"/></svg>
```

### Books / Knowledge Base
```html
<svg viewBox="0 0 48 48" width="32" height="32"><rect x="6" y="4" width="28" height="36" rx="2" fill="none" stroke="#ffffff" stroke-width="3"/><rect x="14" y="8" width="28" height="36" rx="2" fill="none" stroke="#ffffff" stroke-width="3"/><line x1="20" y1="18" x2="36" y2="18" stroke="#ffffff" stroke-width="2"/><line x1="20" y1="24" x2="36" y2="24" stroke="#ffffff" stroke-width="2"/><line x1="20" y1="30" x2="32" y2="30" stroke="#ffffff" stroke-width="2"/></svg>
```

## Color Palettes

### Professional Blue (Default)
- Hero/Footer gradient: `#1a5276` → `#2e86c1`
- Primary: `#2e86c1`
- Success: `#27ae60`
- Warning: `#e67e22`
- Danger: `#e74c3c`
- Purple: `#8e44ad`
- Yellow: `#f39c12`
- Text: `#1a1a2e`
- Secondary text: `#6b7280`
- Borders: `#e5e7eb`

### Warm Earth
- Hero/Footer gradient: `#5d4037` → `#795548`
- Primary: `#795548`
- Success: `#4caf50`
- Warning: `#ff9800`
- Danger: `#f44336`

### Dark Theme
- Hero/Footer gradient: `#0a0e17` → `#1a2233`
- Primary: `#3b82f6`
- Success: `#10b981`
- Warning: `#f59e0b`
- Danger: `#ef4444`
